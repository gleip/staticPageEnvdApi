<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e2893763963e78f54730f81b69ed0dc9',
      'native_key' => 'core',
      'filename' => 'modNamespace/9bc52e744d3d83e82755fc225a6fbb97.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'dcef465692bfad99da66b4448c330a32',
      'native_key' => 1,
      'filename' => 'modWorkspace/8573b4f1578d1d3428916cce9cd6ffc7.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '11326878f4f1028cee66169c8b26e188',
      'native_key' => 1,
      'filename' => 'modTransportProvider/829a577e8371b5373aeed0ab38978178.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '61bc49311edba2857f77d730b7e274e3',
      'native_key' => 'topnav',
      'filename' => 'modMenu/31b0de205cb404c9bddf66e0c12c8b1f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '48196689c1b52427ddfc9ab8d4eb9988',
      'native_key' => 'usernav',
      'filename' => 'modMenu/f4000075dcad64b189be523962957458.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '427057e578653073a2a354c782b0e146',
      'native_key' => 1,
      'filename' => 'modContentType/f435e5b6674751a93a398b118b7edb00.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '314b0a6e07354ad57cffc9b9cd51a84a',
      'native_key' => 2,
      'filename' => 'modContentType/5570da6d9442318501ee26f7710939f6.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c05718a9fc56d880066bb316a4c22825',
      'native_key' => 3,
      'filename' => 'modContentType/d5a14fca15851d0e2eac88a1e931d7a8.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e7712e5e0977d7dcfd048e1540bb52e8',
      'native_key' => 4,
      'filename' => 'modContentType/ec9f38a0eb739b5a2b6c1aae1c4ea3cd.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0b607d481043638fe7d2d84b9f6eee38',
      'native_key' => 5,
      'filename' => 'modContentType/ffa91a67a071df6dbe80d3bad66d825a.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'bd808928451a802d4e855b5fa1f75d1d',
      'native_key' => 6,
      'filename' => 'modContentType/2386cec26e0f62e570ce8f882c25cb45.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '20807d9abc3c59e4bcab209996f62145',
      'native_key' => 7,
      'filename' => 'modContentType/682b1ff1c19f9b5d8b18af54e7bd92da.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5ac97b9792bd60fdf4e2967c53f31b15',
      'native_key' => 8,
      'filename' => 'modContentType/bb269965e94117b5a531278f74fe7b21.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd0906cfefe3edfc5c4fc92bde020600e',
      'native_key' => NULL,
      'filename' => 'modClassMap/b3b0ac22145e0457201cecbd54df2757.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0ff41cef738374fee2ed41f2c4b741ec',
      'native_key' => NULL,
      'filename' => 'modClassMap/05cf295030d906f1335aeb82b51a8b1b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'faf80377141c4156009974cbf95283fe',
      'native_key' => NULL,
      'filename' => 'modClassMap/eca35dad39bba463fb74ebe6ce0637cd.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '29803aebde765afa17074b10ccaaa891',
      'native_key' => NULL,
      'filename' => 'modClassMap/7b3fac9a08e4840a571609c18e755ba2.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '04b1f486de4417cd0a5e911ce04e1b5c',
      'native_key' => NULL,
      'filename' => 'modClassMap/6c048cfd0b1f70a90eda7078e1e50774.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e6714d284c54ea3d2c3c65d66f6110ff',
      'native_key' => NULL,
      'filename' => 'modClassMap/6cced218a3cfba2dfc5b806dc16521f9.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4f0de2cb4e037b4ea1abf76e9d9af534',
      'native_key' => NULL,
      'filename' => 'modClassMap/d1cd4d8ab48ad1710aff9d2cdc3727b1.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8196e4deb8707ba03774f3836ba647a1',
      'native_key' => NULL,
      'filename' => 'modClassMap/559229c838ba2e80881537adb71a5855.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '293df04de90f04634cda429f3894901e',
      'native_key' => NULL,
      'filename' => 'modClassMap/340c5fa016640183f30bdcaa2f5c0719.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd8a000ee0c4db31fb13f781897d4594',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/ce2a001e6ab206cb10750346a228e04f.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7845cc0d8d951274fe8ce6d7241a242d',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/70cedfc71a1bac4fe5aab4e8ee4b3091.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bdfbd5ff643f64fa1de71cac981fdcd',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/d491ca8c2d36fe5270a8eb7c9eb7a0e5.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91fdd61292bb63b91544d27f4eaaaa26',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/b72843a8636c27fa72ad23e5ddcba28a.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1a49a6e2a0f1601cabdd1dcd8a555f0',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/7f12939eb9d69d0df88bcb598208b2a8.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a769f2d44368722cf19d371ab9df2ce7',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/78533bcbebe4b0a18422f3a270c66542.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c75631ba907d59d7837d20bf0624595f',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/affa76c2dc2546c8dcfd8fa827bc4770.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e54c63addace3ba10417c75cdcc86c77',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/aeeac4bd7f468285eecee74f3e9aa38b.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81769b17f9d525505b8ee055ff695f3b',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/4203968e7bd509ffd0db94d115459d29.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83dceaaaea4f7f293e17ef1e3b489624',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/af93b2802186c12e3e87fabb13619109.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e811c1b28a3ca03ed0e4a39ead3b875',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/f982a24cbf9634aa0680f46f23021319.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a77b47ebd049512dc9cde75cfd1f4f1f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/827aaaab2f408f7a44f698d470699f68.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95bb9dc8afc87fdb7e2478c6270269e0',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/a435668c360d68e702a6a7b6525c8c2e.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7dbc10dc8da44d8ea5fd37497cb40c0',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/a6b1f5a168b66e887c18607daa5aaa8b.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4b940e3fc0755a92545552a06f40b11',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/912235fda75fc6cced8c76858d3c612c.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '442f587fdc296e717bc0a9dd4d341552',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/a95ee3bfdffebbb4a61d669235b427de.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fee0683fcaa332f062ba3303a73488d',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/7274ff8146279b2a33fb83abf0983210.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef21a8626efb2326e643416bd113db5b',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/47da4e19e6997ab73e2023e88e26c084.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a984ac7e6f594ebbc9036d0345716a7',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/ac13d9210234d2d9cb383cb8ce29252c.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f9e3a606e0be507d4e1994cb463f9b2',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/57ad85ae1ade06df2340bb6eb369df6a.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '762cad22a1b21771bf66a2533e93108d',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/2d703123b08b17cef0cf51f6b23be60c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51f86eaabc47758b110ef26c528222e2',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/598d9de3de902cadcabed8e7159ad2f7.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42713462eb254a7f5df1199c593a793d',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/78be1e25afb09dfca72a57b99782bf90.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '663abc666325ab106cef656b04107b7a',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/1585960134acbb26354a16fe5abfcbad.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab9c11fc5325a122acf74dd71c36573b',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/0d0dae92a8e44c57ea27ff9ea78bffd0.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ca595dbc0776ae61e6aa8980254af00',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/4dbcf706f7e5d038df163210902de7e4.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0a2475959f685b300ab0a76b271507f',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/40afb790f154e8569d02da7f491b66e2.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02d918c315adac9a3e38b36e902a3e2b',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/10a426ba3e910e5c4c5b23c68fc9b773.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7abc036fbc303395f81ca545896189e1',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/646c5561c512ddcccca4f757dad9ac0d.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a737f61935374d055ccceb118700a714',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/b12bdfb0fd70131480dfe25902cbf93c.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec5543e2e9b849a1b8602eaffbc58056',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/869afc6c68f37327b7da514386ed6976.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38650da8941d7ba729e7b2a56f0c2f5e',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/317005994e3bfed0f981f4490f6f8728.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65956bd59da47b0980490dbb4b8a093a',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/3358bf558ccb856f84c4b74f3119ac46.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9851f65a0fe2fa6b1a2728a0a2be5d9',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/37922c079b4a51ca8c377896e693a151.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05e2a55b1d4d2ffa8ecce5ee4e0ad319',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/3c556181c648b68a152c09ccf1a9be22.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59020d30074948ed499714be2c9248f2',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/5e78b4f0000ffafa9de8347b5e462a24.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4ab96726d6f7e81dee3cfa81029767a',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/192d839edd65aa44e73991cc0ed469d3.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0f51c59ebda1d793353c7205859f81a',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6921c1b76b110e0f1d34f870bed76e94.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a1effddcd6abbfd2253a05d501c7632',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/7651a29e783bcecb256dc3193c649989.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '387c2fe981188328215d39d63d963361',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/8290d82a309cd6baa64954913524e487.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '864b8ed30d6f75228e2b79bac3d7b98a',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/263f6bb418e305102ed5c055356a2f26.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eab53ffe2383b4d01e812e51ad2a644d',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/5cc353816e2ae27b912ba46130f0189d.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '079c38721a5f211899d36747ac52071c',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/ecbd2428a65952766d8f809e57fae9f2.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97d7f79acf30e2851080aaa63dd90081',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/4d53baafa21d05bdbb2f9211b8b27137.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d9661c1c3494b0a34227e0b53d50c4c',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/58cfc7e609b6f13ef9def0c545b4adc7.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58e820ac9696af26a1ae107733155531',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/2bc6eb49c2478ba8c44730c353f013ac.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b36f4cba0e0350a1c5f4460693cf3e11',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/630dbd1f31cf809a600d324663dd164a.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7abbd6f77a08e65b3a6a2ff1642e5f2',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/b36a41793de273d37986c5c30addf31d.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85246cbe4f9d6d85c5a9d6684ff4f892',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/0ed4a057258572d2e75f2cf3bb9689fd.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a90bdf052d079346c5d3f8ccc3856871',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6c07bf07a1b165798c42f82948c8d04e.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f04f701a5a739f2b1f8adb419d394778',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/b83b6b4cafbb3a6f1ffce2898183eff7.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '080339c360b97c2572420b624ab0393e',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/64bce8ba75db4859ecc82dd037802c87.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4260e9b9562b8a840f85933fd4a04757',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/bd0144c96cb1cb31d06851eb08f83335.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f47432ed933cd6877aac778acede060a',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/631c110bc34f1b8bf5c859920b00824c.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54607bc10c879abb3a5d5fd13c858d0f',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/b46235c0e62f579b5219a69e563b250b.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca9e8a6f256c2138d8ba0776d2fd3472',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/0d90b7c6b2e188e0278011a40679ff93.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '076819ac414cda6cc4ed3c9993a52dc8',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/6841d86a9df60df8697880152deb8d51.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '085be2ad5ff4ca4f86efb2c757dc718c',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/a41b6415b8e23c744c6b561273f513dd.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '309a0050aef18181ba8ea33277738fe6',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/cf051a1f517015403f5e782bfe51ad24.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c4a277a379a8548d1b7296631e516eb',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/c68fdc20726e581ebabc1df7f748f7cc.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ad940ca2edb60619fe4b1ec355b8c2b',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/f09ba275589f9d2db1b9d96407d217e5.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ab6dfdece777f23031b17d1ab9dba02',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/07a45b90eb18f0fedb7a07f253b683db.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd97acdaba94c7a3144f4848081465db',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/dd3e23db0c39fb61b693fc4331e39d90.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2be3e1ac370db115b8d092552aa2ae5',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/ff1fb6757e4ebb45be61a48fa50b9695.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75ce80b128f29069d10bba34086f51c2',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/f24cc30855227adf30ed676eee6c15d7.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c6f287f5aafb03a4daa063c5d98d8a1',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/a0fd8cbd0633fe03c769097eec8ea807.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aa3974f4c279f543e6512b41ab7eeba',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/a02e9bfeb953d28656c370deec7eb643.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '758cd5a135100c400354e6855c695454',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/56c65a67b7874d2ed669c8914ba16e41.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49c0d10a8bd504808f8848cffe8708a8',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/86e9d02c2813430825b3259d579a7a0c.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce187157b8f75b4de058ec936ecac57c',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/67ecb9e89b8e3b209e5f2d7bb5f5e32a.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe29db0dc3e2748da36920120ebf51fd',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/2dda7d420672ad4fe885af2f604913ab.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69c8936f45bee4a7efa313ce60313377',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/846013200ae5fb2fbb25086806d72426.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19cb597f13e05b19b61aa99580277b60',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/f0c8d22498e35310361eb3542f72a63f.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb17d992931861a7c0818057ebfc3343',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/e6eeb25fbd4615c8a93831634dd9e8af.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4ed823a5c9d7301544c99e686abcfe9',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/2c62800a99929a8ec33e5222f862fed4.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df812797f1b170bcfda7de994d6bef20',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/7f0b12cd3032d375d191b5509eca3bf5.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88f661ebfa73f9c37b13c14651e0f364',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/8944c2dd0ed6657856d9e8701b8eddeb.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88edbe296c22d316170ec0657c1b30a4',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/dbc3af25824b88a1d68942e90c581c98.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4aeaf0743ed7a24e4189b29fb2604367',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/3de71c3ab2f3fb9c2da4d5fb78ee7692.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96c26d6736d89b08d54d9efbd8625cfb',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/6c1332c8bec4abccca2ec23457bd0295.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64e5e33122704124a3b011fa6f571b1a',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/e7eede97c98867606b5c182f68aa4adb.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3423cec88048d2409d8b72275949fcc2',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/a75cce6c9b984bac40424eb054787fbf.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b0d2928a98932cc4f4681300f90c3df',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/934394a23aa1e4402a2362870bbbfcf1.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '677c2560856b6509131d2e3bcbe9f5ac',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/3569b16facf554bf8dd67c479e6cd040.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfe3dd658bf02e1aeac4fb2e54badd6f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/627cb7fcf7546477674dddce191e8842.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03c4c810bd08276b6506d4235d8c6476',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/84eef85a282a25be598472f8f5d17995.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd97a08c447088c2436cd4da27a319cb6',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/f3bff5970f75a1e2c6d72bb1f1c75028.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddc3e21b27cf146be21cd073a3333b8f',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/87c64e9733489b1e1f49758d84379070.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5db65625a10b1dac20f67145a38944b0',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/77eb8c7ab7ed7ed75e11abfe8fced4a7.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '588cdb9e99577d8e9128b398792c0717',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/8d8a6d374823ec61ec548a86684e4e87.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f650c7ee8d77fd6b0cd9bd995bea3e2',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/5b6ef511058e4d4553cbdc49def18560.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc172da1a801f8f1d3135c9fda959aef',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/3bd0584450c47563b34425b3caa15593.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '908660c4f042bc93fd15e8fda75fd2e9',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/ae4624bf9b9d4d0282140a51d54ef7d7.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d1c40ce92790924cebe71d6f3c7d35',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/aaac82439f3e988a66544276d0119323.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb9b34f9ae4736d5a4601ff14dbb31d2',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/23d9ab4c94ef926eb35b95859faff74a.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2831d1d604dbe72db2595924704145f2',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/b30f49d38273c0f1ea743ad508b319d2.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f90e157f5da272408c933646e802286',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/944cb0a74d0f4e9eb181d0028a6f464e.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0bcdda37dfbe9a2365b40dc8a7e2fb8',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/f6527a931bd30c88024bf876d7b98dac.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd65c5db9a682bc0221d73363f763750c',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/fe471f94426d452dc30a4af70f590386.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f0d6aad8cd1d46f5e57c185c14e8ce3',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/e282a16897713b40abccc01e86cff723.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af6d7a789e19fd896d1646947a90317a',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/a67a00c377cb2d0d1ef8e6b089de6e81.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f782752b7eff49b912c6b5255361512b',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/c8ccec2a293e3b127efe626bdbc8401f.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92f5eb1fb77cf97c0932da806e1b637d',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/77943ea7df4f3b078d7e829d9cd4cdef.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '018c56ac76aebd5a3315ed157eb00894',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/74a14cbddf2486c60589e3f4a179b855.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0af950ce969c2b91c77e2360af1844d4',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/aaf9edc0c57c1590a9b51c32bbaf3294.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2481b6325129ad92dd20190c4e9d3c4b',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/a02bb693946320336e2a99debaf3c98f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72021cfb0c20e4faf79a21a55cae5425',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/c7316cb5ab76eb090255b0d19aefa377.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80b320333a7c87b5879a75610159bf5b',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/ed5f04770870bb960bfaf91ecec11046.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64c1bead82fe2e5de32629670799fcd8',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/908e66497eb4a3c313dec298975bb4ae.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48f1ca76d30581cb223d96dd9371ca5c',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/fa2bb72ae6791693534e7ae879c8f795.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd250ac2f7fdd3fcb8a0ccedca57d45c',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/98bb26c938ec8725e4e8c575e4020a28.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea4c77981fae3bb3da6998a885d087bf',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/6be4a5aec18627f0d3e2e87c04060411.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93ad7d20be34f5d58c5db64e0f53a84a',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/3d9ce0718f929c117d57abe9f8dc7821.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b059706ffa2a686fbc46deb132f7bf4e',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/2845874ee1a50d4e5544c6b27c6d5512.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '120d4c292f4e3f938744a2a2770ffd1d',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/3bcaa12aa245a9c86a8e80c97c1dca7b.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '960c308eaee2ead5ddd7e16051b32fd4',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/e535a3889bab59c015cfeb189c61808b.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02b6b37679e076610601d37977c991af',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/74d38dbd9ce09178cd13cf94a3cdb8e3.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '461f9cfa43cd59a0437dc2033e197883',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/fb91911e8618238fcd06383e3b0d3b55.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbee02988c0b9a82e7c0509ec319fedc',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/3afba5a1805378b417af6d8e7cb9283a.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8725baec81a7a686cc7263ad38a77f4e',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/89fd80a8181d42adc58b2f4900140b1c.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98b08d4e60628ab5fcbb42b3e2d26849',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/2c38853db7f1d4e1986bec75a803d967.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a263e5d99b515404f0ee10724d78986',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/ba213bb495c465938c1120ea9c9fe50d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dc14213f4b1b4bd046807cd3c1af1a7',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/2240d9f88b62ba9bb22a65e743ab62c0.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21ab06cea2de22f27fd746e9074070d1',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/5b3510957e6337760b9bf252c2cc0c7c.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '590d4220f5e801b12bdb25b559c72c81',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/43fbfd2f2958455087562273fde02246.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3a4b9695cca1a5ad835758f150b71b1',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/c8df648e6478ea27baae54732c6dc183.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '732e4edbd29ed0d0cae013051d4e518c',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/1433eb0541d73853d203e088fd57b154.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5faf254394c34c49e5b06ec652ee61d0',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/5511f6569bd100e9d0fd8b9effd24e0c.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9da7ecad9bf73d48e3e3f7bb59865894',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/3310003d0ad0a8a6e3ff75d4f8729e81.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32e69326b7a374d17316f1f2e9cb9051',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/2d0f4660fc6a371f0e041b1d78491644.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a9c5da467f4ea29ab26ecd2ac3b9536',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/2e5573f7feb760a8c010b8d4eeb6f36e.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ef59e8038d79ce365e05b8d877f84ca',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/2ed9f5f304daf6b2fb3d840c7c7a52e7.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1be853e32e379f5cf7d1de74370bccb9',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/a9de6c76d8c126acecdf35a9497fdfcb.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00a3ad2d61119c438e6062b76514217b',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/998030cee8345697e6d0950954c3fade.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdd22195134011c344285b0e7235f6a6',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/2535f333e6e698efb7cfb7ac0e111ee0.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c8718e058867a38d585e79bd030cdea',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/31474c79e8835cb2030a9c788196466e.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fe00aa2fae20bc884f857929a2bc504',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/51c38c8dbf28b220f1a99a7a24b9e468.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90d244ebbdaa7b481c5dd8b4537802b8',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/3c20d856e21794b9101d0c654857c925.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b05ac406c9cc927c3f9f44f14d70e147',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a641c996a1e092ea3653b7e8b39a83e0.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acbd8de38aae3821d280f8694f089553',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/4a9e5edeb1673dae46411753d08445f7.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeaaa2b3684bbf243d0de778b133d6ef',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/388ad6ecfbbaf0276dae3a1832220a09.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c8ce3af0ad0ba0cc60cd5b2724b12ec',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/8f476debfa8b5dd47d63f762527d9662.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de00c3cb50e888efd447d22793c049db',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/b8b5a931c9bd976aba8dd7bf17e1f1a8.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d94ecc4ede93799f27edb7affbe654d',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/b3a774ae4769647bed7be450ee9854e8.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc626b1e92503004c87aa981c93c15c2',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/402351f05dbc045c7de97d0476145aab.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef2027e3a79fafb0bc9e29a07f0cdfc9',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/7ac30337a91276346722fd5d399f8dc8.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '796596617fca803180db2fb44b973c3a',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/d11f525847cfd973ff8ad969dce58d84.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7147df70a5e891f4c1402b44c6e1d7e1',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/0bd0907d850a3b4adccbe4b669872dee.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78c595ae3709f1c97152fb53ef3678e7',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/5662a784c6a5a5cb0eb0468e1dde8c8a.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf542c3fccab38f0be79a191ae47d704',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/b903cbaa45f1cba1400f1e72662ffc58.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '920964cfe55d5c0afb760977ec85dfa6',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/14b38a404615ce79efb506ffa5325675.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e215f0759145ac358ba1bfe81bcbe367',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/a76afd2b12422b9c90b034f678db9f2e.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70f0d3cd6abe6c779ee89541eb4aa2d1',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/cad18d017587bb59611f08edea8130b0.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef2c51eb93b70f8d16c0538a3aa05c94',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/7945edd5642cb2ed3f087bca09424e80.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a480b3e9ede7dd4717af5bc92e32e2ee',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/80f49466697fb8c36600653711abcf1f.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e670844b85ba7fffd7bc4c5d67e6dea7',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/5684de03fecbaec66a2e2b66a48a0155.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a93db607937abc8913009746ae9b6e7',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/b2b329972fcef9d6fd17c4ee33229c89.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0888758e982c6c48c63b4edba940a29',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/b776dfdf1c1f6efb53cbb6c97f21f399.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf204c053347a5ab64679e7b739ff434',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/969579253eb80d1d7e80b947bba248d8.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac64471e4a734825ccf9388675c4bb13',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/c5699a42a295aaa64cc82256e9ac7b27.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '569dcef0ab0ae0717e7c2c50b3dad62c',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/6d2ebc34b2af463c0a3761d28a463b04.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5c3d1e550dc9864bcbf6fec85213c2b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/c4383f336fb2e73dae95eb2e14615e3b.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9a6c21e9d2192f7de9bb19143208f18',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/a330d1b97bb14fa6a0406dab611f1d57.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0358822434d506733cb8515761349f4',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/59307de29ed5cbfa8df2f4617c0accbc.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a744bc7c3a773879aa174aa44f64cf90',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/0c4f1b8a6830878aa1bea7893a401a20.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e6a338586e899e60e7e9fff38f20138',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/df629ba34bfddb796810b9c7445e4e0a.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da876d8d22042f63a91050ea9fdc7a0f',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/55c65c166ce1496006ffeec7f6d9524b.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65a4d295364afb44b79e925d71186efc',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/8452382c42f251e0ede9800fa0e14f58.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01ca9af85040794a997144372c5b4da9',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/7268ce724b52453ae496309dc9007c13.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59bfc68861e09a5074e413f3b805f619',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/c9d3d61c169c53a84343962379ecce5d.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e39df096e22ea79e73af02152dd44b6',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/9221dd0d7d7ff0e66c208ae845905174.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd997154c16a6681ec2cf403328fec0b8',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/d20f94f32cf0a4db06f9de3144225a3a.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '744524392ede20104d0a3149c5691d8e',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/66ea8c7e11ed93e29b6adb444ac4e74e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '363a4ebe808ff49a1edcd0edcb6c8203',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/7ef10590f7395ec3eac5979f8fae3dea.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3926b8b6e420affd43d41bf328459bf',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/12ecd3dd041220c567ac2a43fcc83bd9.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2d3753ba3f66887d9253dbddf3df30a',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/6f34b2e3290fbe1d4b9c8e5f9302acba.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5ea82343b26669de30708013e2aeed1',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/ae2741f264485ca04696baddc0b4ee8a.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd868f047f17e36401f1e698b6872a418',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/30140fafda821305858b317ba59826dc.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b80b0fc2740f3bdb48bf6a854bd202eb',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/3ddbff0d9b3e9c47610c49ee6e29f8b6.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f940d9d7624b7021e0639eb834f0667',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/18fd7b500175a1c9ee2818f4ada16d58.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c98fa44012346c9a166655de67ec1c5e',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/0248b379aa60f37c40d5cad931b412fd.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97f01527f2c33564c23cdbf97f0ca283',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/1b390968c057cda58679fc99c45d9963.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37fd62f9d3560a6fe53054b453074ebf',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/e6d8d35bd42c57e5e5c1226eeb699231.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '607ce1347ac0aa96cd3d4a4dad6487e1',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/8ccc9caf01f1fe0d7171d4cfa5ed6383.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '662cf76f8e205703f836f6582b8c8be9',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/ab0799192f40df55a09d715f3bcf9483.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784a1eaa288920aec47af67ab1f693fa',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/2a48786c7778005480fa3a8606c52d53.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8b6053259d55976dbbf396523193bd5',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/5793598a141f72d3a022e8b348b2a8e9.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '001d0a7b0197494f396bee731bb90bd6',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/2423787c6b5dc09c1f4abe03c885ee73.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '403b24ebfed23d96b3bc225be27cc465',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/33029cef7abe6a76a2b79a9112ec4e3b.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b17c2ea24c2dac9ddd092cefcf0a680',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/739a9287dff38bf07a162e934606c9d1.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f189beadb4044ab1245be9a08685dfa',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/503110d910c07818934979a5739fc431.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd3fef834e83b2b714effd83734eb888',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/8a9d374df11c86ce1c8f3f298c4262b1.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bde948656593d036ab89e08768f5e94',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/4640df97fc7fcd022520562436377952.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0089363f8d43931bce9a913178d10dae',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/00dd2729ce85f0a537a888d516b2773b.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b4c2f4b75ca9c23e1d126a9e4c46351',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/4ebef04ef4834231a45b0efe9017a419.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f59e37bd0a4aa677d80b2bee4283ee46',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/496ffd03d905592f38a8d6552339eae5.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da38eaad888e5fd2694e6c0113d00481',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/bc67dd3a43356707a3c8685079abfd37.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79ff45b913be56928fa7abfd47188695',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/d97c0141e43754f0f4e65abc0cfb58c3.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7716d866e05a95edacfe67fc5644c0d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/c76ca91489921ae0056af6e639b01e58.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '516710a9c10aa9ff0963f415f6543d4b',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/91dea1d31af556b5584aa5dee132a98a.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce603ebac39607590671afb15a943f4a',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/5bb7da5dbeb1bf4abbb262a731ce0e52.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50f0882d314e91eb1e0d115792e230f1',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/e6701732569d3e0fbdb82cdf097cd55c.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03797f17763a575530053162decb920f',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/32a5521e0f7d96ff110ad0375f8f43d5.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b06896ada0dcb2ef601fe81e99179db5',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/f8d34763ea479f307b4ab53503db7216.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a232052520460cd558a47cadb969d102',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0d7be971bdee55338dc11fc54dd70541.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed90dab08c7bd750d04d73bc847b9134',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/efd49d5ddbf5db44f2f6720537290da6.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f0d98e9067db0d2df48b7b1bf8c5b06',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/f5d2069518033cf01815a4b6d6be5caa.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2c0736ab96dbf5e54b64203f1640cce',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/67f4cf1f2e3bace9cbab03c50584037b.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea3e089a566a0c8dd10375c889b8786',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/8f59d0f0331d6dde437c5d9eabfd0477.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ffb030fa85192bc62010a60509d1d5',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/9e0e09ab63323b43b937454f555f0eed.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ac219390c639e13c32885e31385f45a',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/1e0aaf60a96627f860e1748069ef56d8.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5fd27f1de8e1cf08d2722826085327c',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/e1c20caaeab31dd86fd84bfe51e41280.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce878716ace19addf1f8f9b9776447d0',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/765533fb9b05afe5aa5bc2e6c74b5936.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bacb0251694866fdacd20c4365fb14b9',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/b9bb0489ab64613d4ca50b9fe617d030.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '574f0e4ed7f6f8d4b164c8696cf796e8',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/9785da9a00aac602bc6d7fe24e53da13.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f92fc66b3caf54c4b5473ee0fb65574',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/84a24e0e250b63cd4f7e1aca0f9c5e48.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b0c12988da5573dc55b2cb3940e86f9',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0b66f05266159cdfb12884740741e1fb.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f73f53d0226bfbefe1d8062bc395f76',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/434abdacf69c500cddd223297249ffb1.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35ea256c897bdaa36c7c741c30ce3ee1',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/3c73437ec057e2f58bbbe2e27865c647.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ed201d5e352461246c2deaae5e7498d',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/5fc442e58591b41ef7b305e55c044f91.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f129405dc773e3180372027814d11a',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/2d3c1bb99f78c2992f6a1f9dadb5875c.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6870dccfeac1413f02c329aaefee8c8b',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/3df279f1f771db01848dd74064841896.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17db2f29a5b675545672b366ab53d848',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/fbb1104ec99248195324676406f7b06b.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e0bba8b438c7844d47d186d480f2f9a',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/50993fddb8ec26df7d877a7aa111891d.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98337dfae3970c838582bf703303e915',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/5e8316c313dc56b3f97283d45900d4d4.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a121d1f40b40e1e0252f6e9e940e6bd',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/7745cf3d4d357a2e12976cfe4a748cc3.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0272f435d46894372c4ab725a5128a1f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/5e7cdbc0dcd22a8fc402891fd25748f2.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8f6504908ca583d2c5d7e506b796c0a',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/68329c13350b011e6ad2921da24fa8b7.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b0508796a0bdd422419dfae108979ac',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/0d0dc8f14eef6613888fc58fb8e205fc.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e09dbada8adee271f172f9b1ba5bb40',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/374f028b686d8364c4316f408d6f8086.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '967685983d792801a08f3dff4bcebf6b',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/efac84f5ed1981b2774afa247ac9529b.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeccf9d63ef4aea08a4301257e5241df',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/a4aac7963bdef21e0b1a47c5a69d21fd.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc2df7d1938a2419bd01e39e47898563',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/7a5ac0f35642dad9f40cb83ec2de6fad.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e7e7e02db55d042dba61f97bccacd6a',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/73f4ebfe3dcb493acbe97fe018bff183.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b484277d224c3e68b2e57c4c23a87eb',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b55389816af386ac139fe13be7e2e3c6.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce433dbf321bf38df74ecdf900179c6f',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/6dde4bf2d436455f31a918e82001013c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab67e156afca5a0c8616e9840b92c108',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/b931bf9b5d28b48752bfdd2d581e2353.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b5c878e131e710dc181d7fa94a06241',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/b60092f8a8131d8313cff03b818859f8.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50109180bb12d3cbc8d2eb56740e329d',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/ee44e334ccfe3c0c16fa9f161708dd2d.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52bf1bd398facd448dbdddfa7a16f50a',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/8b43c705a473180823e722ad90260fe5.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7574097eb031b489945b76f2efad01c5',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/65092fcf899633dd7b49398ad935bb11.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eac0976fdace5e2653c208d50e88d043',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/b6f90c959c4da8b3628a7725f1f50d66.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f6133a9a8904c2ee2f1f2e3be8a42c',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/7439a24dae9336500ff5cb359c305093.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e3ffc9c0f5a35c805e693d20f40d29',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/ecb76d3d62248790ad0def74258a657c.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a21b5a1d235514ea4c33a4466e36a3c1',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/6627de93129d24996cf419d9e7f3ea53.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff0a228b1a699bf6253762ef16439052',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/616802c7e9ea0e6cabc97ff906c0fb69.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7d892214adf7269e3279d4db82371e',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/21b72f165499398e1a6311b589202cb0.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b7145fec189e1286c84ab9484782cc',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/e25928236261bfbc854510df6cbc0525.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2641992dfea0dc83b589c19f859c112',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/2c83879440ff04da337975f819ad42a8.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d359607225fc3f42e9de81dc296426',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/0c483b5248aa80b1e850176bf7d5c054.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b504b673546dad62bfeae37e5ad66bb',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/d7c8a727f7cedbca8270cdd1780f2c5a.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c54e734dde11c486eb292b6075d80ce0',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/2826e71ab84c40b4617bde5ffb849b17.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39c8db56064ac0c7e9113a9f6971fbb3',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/fe6d6fe6b98a7a7627604caa76e92d41.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '365065fe4aebaa386f84f8a0fd520e4b',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/3bab67e965f3b00d4954c5b5c8701f30.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2187c828a2af1e15f22856339191ecaa',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/c93496c720df185bcf907cca6cbda2c5.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '828568e495193d30a58b27e1e135062b',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/54f58f84ba58058c68a57e4aabd0e6a5.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '372a87141b37488fb6cc210b5dc8e3d6',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/2279321352439a4ed388a3472153c06d.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '662830bd49b76971d539c755e6b1162c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/f3ea81d54d503ddd204c72b735c94b1f.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28938dc0b3916c084d82a1d77c96e8f0',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/8d8624ce79ec4ab0ad24476e7bf1161c.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65d7749cf496f5d5386c9f5bc7693d67',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/af31f5c498ab956e6a87488681658f71.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '378d51a15e979745f05088d07d3d8f20',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/6807152113b7ff5bdaaea918048906c3.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5e8c649af1d0ff1caab5ed4dfe297da',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/235604727b1db0afdb7c974f27ef8a76.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17331eefca676cf7095d1650be587d63',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/c71f3c606f519178a78ef87aaaba994a.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbcd164c7f19526096af9e78dca0d8f',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/b73f71ff74c49752b04aa72984bca01c.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3b6fd58f33505b3f0181831e1324120',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/2c8bc30be3ba6473b68fd12081c9d619.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ac63b8bb0ea2b6258efbf197ede49ee',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/cac9159ba5d1a74dff5d443684b925d2.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18cb1996e034037b9043faad9e08f349',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/05708b409100f649890b5f8bca3ae766.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f2562c274e14eaa591ff9a0a63e81a4',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/cf8ec5d6d798198a4284cd795c728488.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30498adb864c2726900801836799bb3',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/1eaf69b52ede7d78ce742ce24599fd8e.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b9009d00ffd955e976916a66d9d727',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/a28c5b19aa3c16239b304c125222eb8a.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ec4eeea8017af6e3c34b4736e942184',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/664966f5f3a1581643e82463bcea29ae.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c5c6f9350ca5bc463d5233b8e2de209',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/f99a6809acf03e579c2593bf74ba337e.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e43bd779a512b5403ebbe5bcbac5f334',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/77716d8c1ee442f74512201d8591c099.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db49932e677c1c41f2efd298f5e5bc94',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/454d302d392b243d888290a8ec7c22f0.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56076ff8d763e6d5109b3d7dbecf73c9',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/719d6d98f568d24aec8191923e4a0b3b.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e99a366db918e04feca605b4981b74b',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/e5419cded84868551350aaf1eb280c7c.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69ace96f34ef288def916d57f4f4340f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/1439dfaa4bd420a2aac40c7c616cbfd2.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9884003f8a006ff96085d647bb63fdda',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/bea8f13d7a4f837871645972836dee91.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cf2b3a6e68c24c738ca3a3d8e4d1f83',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/0ab3a3dae7b7ed1135fa7aee7801c32d.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea1f1b5ad5d6f610f55e82e96e0ad858',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/02993f85486ce755912d89dcc4d409ec.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d3ffb352006280e504a0ffb09879042',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/f3bbee246f2979358b5bedc156526a9a.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03346ae31c9d5196b8ac853e7c808216',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/c19c378ea70f465c004ec5e07fd23e1e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff651a64eb0d96975b017eadd861823b',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/920a07d1edeb435ed4c6f4b84eb0bd07.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '193c25f6820b1076f271b5349a5a7fe6',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/cd9c7dc4adcc999502175bda78459a2a.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87392e8347722d6f8c9f61948e0d9bb9',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/3653a09f5327a2e4cac36aad94e4f1d8.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39faa4cf009ea628b5b4428c057ab7fb',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/1851e67de8d0e799d46be7df3cdde15a.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '925c411e2570b562076506b22afeba06',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/686b9d3210504036db3109c9ca53e7ed.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8da5ceafb89652b95043a959b68300d2',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/0147a2a4ce445dffbe83046deee5d65a.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '936aeeba0434775712ae3740dcefe0eb',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/1f3cd05eee31d70816369ceb0feab18e.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7ff0ccb675cf7c9c5e654f1af2b018a',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/23ea8e86856c4d374b99145793d2d3d4.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55fe4d0688f48c301582a8ecf46bd8aa',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/74449b43f84dc4c898cbe4b304da85bc.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19939853be8dbc86b279c420685d6317',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/6347f559d2b64302c505d85320731abd.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aeb455a8d73a567307af2c75d01b4e6',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/01b1cc2c8517a9fdbf8b8825684e6d9b.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91312b8eec665e4373724c86e959e373',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/d8b4c519687bd36078a9712576524537.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b681ab3fd71a6dc48647a3201977c79',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/a0b7905a7db6feae30890865e4d297c6.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3675c4e17508b1fbb1dad980c8bc8e6',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/50003aa449eb28ae23a34c688722b118.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e2da4ccf9bf440bb7b3d75564c5ed41',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/26f1b325d6759a28accb59dc4d26954e.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3804bccad7b89509294b59ac228680ee',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/ea518bd48b0ec5cb53112ae0045f5e9a.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7df23e1f19fa7a1601ff5812999231c4',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/18d310d6cc9eb14dc09eb8a7b6d75099.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eabb29a036f46ed569a68fffbb4449bd',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/7f130165adb281623516928ad8424b58.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99a25d078524e62a885f69ac4994345c',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/5838bd9f7567d787f8103523d08eb92d.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e39b6576901cc1f779f06f2cbb3174b',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/1f05b8886e0c8c3de134272c35ef1c30.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1403e522fd0cd50bd30fd806a1bd1d55',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/497dcdb2e26b2252eddf5c157751a0fe.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '170121febf64f5f95ce392c814fc3b49',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/8b719c4d438eb8544fa71e656b93f4b2.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d6c8d46a37b924477e982c1fc370109',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/f6644c03e2c29ca150e8e9896f347924.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0d473434a1e673529c1106310217af6',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/731dcdc135da47f2a08b3ea9a643622b.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2826b94c35de34f3943b6c3b43d70e7d',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/89b5676cb1a5c7d2ece667a0026c71ce.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a3b08200b12be90dbbb740a1e37d3fd',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/3e0a6b505577bf8a013f97df8e81df12.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03e19c2b6854c19ba656ed8af8cc5359',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/4d6fa871a596541f481cdcc292bac7cc.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1efe87fb647c83b28cce434f1967a9d',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/57d7ea14bfefe1d385840fbf9f228b26.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b256f3a5875a0c21b7a79203ed526957',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/d627d99a0f508c13d9b9e4fb7e62c6d6.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce4fa149d5d671e51571b7a810449036',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/22c7e66ec81a5ab75a0b39fd719f1ec6.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67c23c265dd4480b3a5c486a84157330',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/cc061dd2db64aa718c2d5e9334c9f7ca.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2896b2e86136ca8b24be571200fa9349',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/9e93cfa26ed7fdcbb29398057ab1c846.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5268c4b0056608df6defcc67e8cf958e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/9b707bb5ebbf76f7b137f9b090dce873.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd75cead8335504ef26e52bef186111d7',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/4976388f8cd538037c82dba4213718cb.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7defc3e9c9fe8d00eb3d723d4f9ce28b',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/a8c5eeac4c765e3b416b5d6ed341fb92.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ea6073960f3f3f51747f4465d7201df',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/d1fd1152cb46f82453c62bfcd33c9451.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7d4bc3b604f457609eb9891074d1561',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/7eb00dc2bf6286fe234aa62338fb62ed.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47cf740eb5a1f8ad9a6e017cb479aa75',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/83c1180f76087ce49e3bdd2ca2f20a10.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd94b6fe835379aac3cc8e49c33cec32',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/3c0457a2f1f9dcbb6bb66ba343380110.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6289779e40e6510048dc52c14cabd014',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/9805d4843de037a9b3ee683548a529c6.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c035711630abf27b53294332fea0ec63',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/2ba2845b9928324cf8f4a2517e2aab1d.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5870e2b1be330b6abe336580a65ab285',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a6912570f81068de45284d7faad97ad8.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dd9703477606e3bed5d2d17cbf8b9a1',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/684ad9439bfb2167561e9194df46f02d.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f12769a9571b97bdce5380a8f8461822',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/f659f7e8c6ffdb72b35195e85c9e0c4b.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bf51451377c1087fad67cf611b0e8ba',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/6a44d487f3579a8c54fb2f46c6f21533.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '781841083a775007018682353b0e23b9',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/9d30576ecc8026bba3320e1f7cbdb600.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0477cb81db1a5f2afa3001affd1f14ea',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/20b12bd5a6f0baf1fbd5f6c360c970d4.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7927c57b6303a2dc6d1e56d0b153b5d2',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/56edf388369d0728b38fd856ad261e63.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee9153cdd22b6383ad1a97eb96e2ff8f',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/2acb1eda52ff7264787b217ad98c525d.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53ef6b813912121762835bf7eb9d744d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/62dae91f1897050926ccb673d6a62a92.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '822ca68797624dc019f9a0c155064fba',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/59cc823ab7ba3b5e25c3a065bb79cde7.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb1a6ea9f59c6946daf0ae2a2fbbc37f',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/fbc562db393d945e235c6c30a84e6840.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '959ad7eb1ea26356cb1b11e83dd42b38',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/1dfbde10a91e0559ae35119afb0a5df0.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca09fdc9f595f8ab94818faf2a099936',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/e0a3477567e6048ed047c908e9457dab.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faac6942fc9102a1c5f2f66a6e9fb581',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/a85ab4dc4d8ec190f42f70627cdc679a.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3a330912c768566c95aa9e0c6452355',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/9d65ff87fd1057bec99010a641da1ad8.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43c13e4ba6d7ab9f1d75db04a02ff5d3',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/d3ec7bbdfa83ddf6db2b97b039aba683.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f94857940ad9b41a5ef885bf815e3cd6',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/81f003c20a9c6744a76fa0179b1f7b04.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fe3b689735e072cee18487bd05ca228',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/f0062f213a7587251571689456e37f3e.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e40ba442b5628e6001982ad4d9d03b0',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/391274f0e6874bd4114ef3e6f6602f7b.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a11ec36039550d94f20b2252fbabb39',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/2425e9b825933d8407389a1fd74f4888.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968aa066b3fea18da52e7e46e2a9af46',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/83454b8a56f9ed4470a93bc0158ba4c9.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2634dc58cf7f6dd30c65af7819dda45b',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/21931db232dd593e2815d2d3e53d27d7.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '800629d0387d954a9a08b0835c21162d',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/46adf05df7be0be4d0f7b4155059b3f6.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e23a4ba437ce974057000ca697782d7',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/2f755d03e039aaca278c1c4b08e55ffc.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d5227e27441c12cb39842244fdde072',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/8c7d97a6a8ccef63dcc6cabfdcf948d7.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a13ab6abffda1c1b38ae917d92ac5c3',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/4d77f383b29b3c66c2620ef9b1cf7a7f.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c313e2c0e9392481bcf16e344ee58453',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/14a00b26ec268c5060504ecbd29746ae.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ae7bedf652efb0b5328f8661c63982a',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/9e8ae61f0386c8fdd39060bc4096d459.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e8c457efa88683bdc52824076604c80',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/4025bacdc041d20652decfa9ebe1035f.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc67376b70c59970639380344d9cc7cf',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/9369b09ebf25ea99192031680310ef40.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '276d812cf641a7d7cca4c1d56e1194ef',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/13ba95251259acb9ff0b13a29c7cd90d.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'affe9f73ed15ec3bb8ba49df09f37af6',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/c34b81eddba4168a9a50717192e4a440.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1005b2e5d80ea5ea1c79467a5595feca',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/588338d43d2b0ef14e991ef2c8dc8f83.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d40b21e4ee74635f92e50f3ec1d8720',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/9d30c2cb7f006c352b80c3ecf9b0fa7e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c238f02ed7eb028256aefc9a32bebef0',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/2f86eb0f9cf9974191cb2538596b5c8c.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '407a205019a7973c33657a4944f873fc',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/60f983e2b57225261661e3c54355feb8.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce6848a04438f9e96ab3e98364d23f9f',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ffba9a60b7a04597bcfcf71aa6bbd5db.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f666825eb7483170c4513dfa5beb48ff',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/12efcc94b1284c1a3890f2c1c1bbc167.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2237f2ec07c47d48d647e87b9577cb7',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/0f5e7ea48966b305efade11f8022b493.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bce158c5927c1898706833f735bf5031',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/c76c22a6cf2bebc441fd26b338f23ca1.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87ba695daca56f6ac2b180959ba72cf1',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/5e860b3845a34ea29ec2be3390786145.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff3deea406a9602d76607e8420d3b423',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/c1e6957277e6a293c8a3c689511029ba.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6abdb476c2d1381d39d1340f8433c571',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/13aed36ed0ecba58086a9736af2883f8.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc7f554660fc8c5e9155a3d2c20599a7',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/b8d139daa715527415caf1dd44837339.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c2da2532e8e741e8c072d6976a71eb5',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/3efc7e41138aa96272b1288b5b0a8d0d.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc489071b09a24277ad066092d3afd0e',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/c5d918e8990a19980b02ce7b7750c5c7.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c31d69d3bd37db9bde67d1e1a41c23fc',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/d0eb5674ad495c447e9ca5cc98edbf37.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff9f2240c8c86c40becd871be8afc8ef',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/c6b9bd7a4548dba83310393a9d6abdd2.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cba10f4f163bc09843ce1e6d2fe600e1',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/a4ac97cc8c88df671d05457229071741.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '840ddf30509923d54d5e24412fed3a34',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/c7b97030adb0dc0762b8c3a80ae8b429.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51dc52fcc30e70e9985ab1dc4999bb4f',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/4c3cd099eca8933c9c5480c32157cb95.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ab3bee92dd015690aa074012065586d',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/588b3b8c6f09dfbb78e7b00ddccb15de.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7110f206e4b6069502316fe287f2e08',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/0adb4d3a87dff6e3884ed363c3e0eef7.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e3e43eb365d164d6e2a322841b65b63',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/5f70cd4e9fc32171641928e343afbd24.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bca914e3269fe0e80af78b1f1aeaa50',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/aaa788bdd5a478afed1d7c5028b936c9.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b13b1fb653aa8fd16d73db3b1a439dbc',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f75b0af47410bb7d17ccf863b30aacc9.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954f48204c2c6fefa56c08101194e66c',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/6d2c2ff6d0aec29fc7a8c8dae803326a.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c6d07458962ce1f8ecb4648fce30e83',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/316cf5525cae167d2a442fa4472cb8fd.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '865a93e777491a9b537af3e854657aed',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/fff621960b1a658b2d621d0dd9af0147.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08bc78f3fdee5ed9c0c3b177e9bf1127',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/ee1c4ba8cd5619fa2b7a9d4504ae1a63.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceface761755962e58457b447fc58b43',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/dc09b4506d9588876580e17eb403bcc1.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd96bacedc6bea4c0f7b063564dcee3d9',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5a96f57dbccb4ee08aaa3e17d6633ed2.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec2ea8dc5555fcbd33ceaf9425e15f67',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/59f9588cc41729ec32ad3682750b8650.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ae381f46bc71771420901e09f2849bc',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/f4de57aa3e738f549cccaf263e6c9961.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47dbb2142e81c6bfbe0d8f1603004ac0',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/8429eec13a4c741d8e493c1c77f0a923.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f9a2d594d50e01609729a730effe24',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/353c899bcb971e249c91f0b3af162b20.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a8d223b3c12b760540acc03e063c85c',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/2f5722793f58554895956b0496a79e67.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '073790ea161dd492180aca11a05623a6',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/05ffa597195816f437f091d5dd2011c8.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3786b9b3683323b62fde683a057bce6',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/f9d3dc51b44e3babe2d49fb9eb2726f4.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28d8925e63d39968893042759945078f',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/fcb78ee4d618e69137e5d6508d920f7b.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65490c901902e697d97d4aeb807edc3a',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/dddb2432963853ee10714be078417463.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57a00f618b2b73c39b2cfa801e32113a',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/254ac9ade5288119245df5b1b1b501a4.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65a7814ad9dc84ebec26273a59a05814',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/a23bc9ca393f9259a7ff7e32ae5f320b.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23b95bf349ae7fa4d639f7fe79f0a3f7',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/9aaa907c62797ba3a00a2962a6827ffc.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd32256ea2ae9f4f6853725ebc4ae7162',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/bcdf20289501b504b110a77ef30832e6.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0882337536b598d121e3bdd44cacd7e3',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/714f7c384b708c057e146a96c76e5c9c.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14b0c7f3003b8b86c6d442c6f80ac030',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/105d782b70e2c032d22e7ad00a9dc413.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c53ebf7eaba3fdbf7cb24f72c5ce0e9',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/df67283264cc85946e3ef5ab10c0cad9.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a29e1cf5b268418075374493c7cbb6c7',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/f93572a0b77aea31fe1d69ec0c6d64ce.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ef737197851ba6a20e3022234451eb3',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/80c29588839d8fecfa987e2c63a5d57e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d53fab3c82713307e9cf2d08c9091c4',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/8c345c1774dca65a7058dfe34975a4eb.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433311a05a299090702b9751be28b4e3',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/bc4f35405b239006a1105f1429746356.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ee0d37788fd077ef989b98325ce5a0c',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/92684c04e39566db8c407bb6871dcba0.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'fa61cab7d0a902cffec2b699e7b42546',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/1fc89ea9c406a6ef91ad7d337e7e522a.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8680aa3ea2fed7c11109c15ac1b0ccb7',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/6bfe615a375a3b26634ecd92c4728bb6.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'b73110900aeb84873246086e00bd6eee',
      'native_key' => 1,
      'filename' => 'modUserGroup/6ec1d9fb0f8da4c03a2a9eaabd004be7.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'be1b0a4305f6fbca2379d5f9d2814c5a',
      'native_key' => 1,
      'filename' => 'modDashboard/e0d0214069f5bcf239f0c876ae20ff93.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '61ab9539614118641e6963c494775b68',
      'native_key' => 1,
      'filename' => 'modMediaSource/2e93253291efc5d659d0e22640bdc513.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e720f4fa4ec2effe824528d9ba8fac42',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a4c2c0934d4e8c59dc01a02434591f49.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f7bdd29c91496ec26d5d62ac6629fff2',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/534666c7ce747a105ef9159d51d09f1a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '188858625aec92fa44411b509ab9d154',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/0c629283a44b2e7d6daa49ee9fd60c8f.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5b39ede18119addb5ee8f57debc8a83b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/89aec8dbcfaff0085114b461d7f4b110.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '70bb24e2353b8666fb5c6874597d199c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/da108f0c7ddaf4bda65da4185daee127.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'a209e32e05611a15584232ee2744ee8b',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/82d730789c41dbdf01f9777f6fb491da.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '73494c682daf05db9ea0af4fd5950300',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/245846a9efc34fc7310f4167cec841de.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd1636b3e7f495270a84874cf996261ef',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/44ad44f1b099910b55209a9f09b4494a.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7b40c2eaf7bf5e05c625ec2c13132d49',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f5a9050b9c19916584993358ac920955.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '76e082d555ac6df9e272b557b156f568',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9eeaf34efea9138e61bb90384be20673.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c4900074cbb98264f0bbe8fcf6cc861c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c016635b01e45fba9757e291bd925d79.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a955a874ad8aacf800cc83371bb4ef58',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/81c66a539b00c4c404a00c17562cbe7b.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '36baf1b060ab8b7dfeb80e62a84dfad8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9ba9ea8bfbda66e4ed65e3df086b1157.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ab8c047ec09a65a0a770705d17ba11f5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/50507dc23f73e0e7eff17e692349ce63.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ca7b93f8c174c8205d37a4dd74aa6765',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4df8a488814763ea633f1d440375fb03.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '400f9ab4385acf6cc7507286337076dd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9c9bf3be03ebbc09fb044ba3a358afd4.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3c078d64b264871bdf77e735b1d3ab1b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/67118647f6c553ef7730cbf5b2174403.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '941ed2f12fde8e8a6fd8d6716aeae066',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cc9152da385e3be1da9755191cad87d4.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'df8f09e5b44243ff8dbcbaefcb9b4bd2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/01fbcc2cc2e23fe4ff10682a17730023.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '009543c03e373c334206ca5396356571',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/67bb212d981b3b6b73a3614680ebc7c7.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5e8d95c516de3d68f7da130e7a7cacff',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/09408cff4b01e8b90ec0f8eebcb5ce0e.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a0f74374e8d7ad0846c64cad2c7c96ee',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/654ad05153b589a2bbc5c36f38b1164f.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a76c2c3c6bd614575345d98b24d9393f',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/85fd59c2c91faa075954547998b91f61.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '219cfc3e144c0f684474c34a0b4a668e',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/dd60014196e8b90f8e0840bd1e27555f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bbd327a3350bd62de5525bc658f2dadc',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/0199e5cdb2294377d75c2a350c85a587.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4fc68df9ab090cbff3d3c1521bed2d39',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/b5fb70fe48bd5b66425147c3d3e885fb.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c7707f12bfda30966a2d366a1b95813e',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/464e15623b0c4bc8eb3de7e7bf533dbe.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '08f850a7927ee0dbd3095bee3bb98724',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/47122482f30e09b05b569862afb0a8b6.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1eaa3809c0e839bac6dc5ba05df89472',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/376a67a2e07a597894ad7a1ecb93f99f.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b737ce5068133bd97b5c7e6fd042117d',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/4d9f7db01db31fe7671fd9ea7e21163f.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '736ee1b301931a00b86429a8691fc872',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/090bb2b4fe2242b83b94365cd464de71.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1b3eff94aa40a3b2d955628ca5d11969',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/4f2065bd6db86d7d25ba77f990b90835.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b697a2f91f1e3c5856274ee8b43afdb2',
      'native_key' => 'web',
      'filename' => 'modContext/2a724313a9b7e6abf3d81c60f57b2e63.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'f4d3b4dcf3d660f30fb3d342b982c1be',
      'native_key' => 'mgr',
      'filename' => 'modContext/87fcd742aadfb6c7056f8af912fc5787.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '379b112db3c966c7695df28a2a61ed9f',
      'native_key' => '379b112db3c966c7695df28a2a61ed9f',
      'filename' => 'xPDOFileVehicle/d814151617e976887af7a24c1ce65c78.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1ac0496b9cb5f25ed86a2ad8f52fa2b9',
      'native_key' => '1ac0496b9cb5f25ed86a2ad8f52fa2b9',
      'filename' => 'xPDOFileVehicle/5c11eeeb6af6006377decec1fdac1c01.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ba1484d5a1d2114cd95c38ce33abca83',
      'native_key' => 'ba1484d5a1d2114cd95c38ce33abca83',
      'filename' => 'xPDOFileVehicle/a147d2ea23b7e0dc1d3038c829e529c8.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '474655648688a5181ff94c08e82fe99e',
      'native_key' => '474655648688a5181ff94c08e82fe99e',
      'filename' => 'xPDOFileVehicle/6ae8d7fb3556f5083957458d7c407b11.vehicle',
    ),
  ),
);